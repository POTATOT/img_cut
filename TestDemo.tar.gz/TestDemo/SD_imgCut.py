# -*- coding: UTF-8 -*-
# @Time : 2020/5/16 16:17
# @Author : coplin
# @File : SD_imgCut.py
# @Software: PyCharm
# @Dec :
import os
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import time
from skimage.measure import compare_ssim
import skimage.io as io

def get_img(input_Path):
    img_paths = []
    for (path, dirs, files) in os.walk(input_Path):
        for filename in files:
            if filename.endswith(('.jpg','.png')):
                img_paths.append(path+'/'+filename)
    return img_paths

def split_img(src):
    # img = Image.open(src)
    img = cv.imread(src)
    # io.imshow(img)
    # plt.show()
    h, w, z = img.shape
    print("w: ", w, "h： ", h, "z", z)
    print("h/2", round(h/2), "w/2", round(w/2))
    #按像素点拆图
    subimg_p1 = img[0:round(h/2) + 500, 0:w]
    subimg_p2 = img[round(h/2) + 500:h, 0:w]

    cv.imwrite('./data/subimg_p1.png', subimg_p1)
    pixelmark(subimg_p2)
    cv.imwrite('./data/subimg_p2.png', subimg_p2)
    return subimg_p1, subimg_p2

def cut_img(src):
    img = cv.imread(src, 0)
    # cv.imwrite('./pic/origin.png', img)
    mg_medianBlur = cv.medianBlur(img, 9)
    # mg_medianBlur= thresh_hold(img, 150, 250)
    # mg_medianBlur = cv.threshold(img, 100, 255, cv.THRESH_BINARY)
    io.imshow(mg_medianBlur)
    plt.show()
    cv.imwrite('./pic/thresh.png', mg_medianBlur)
    h, w = img.shape
    print("w: ", w, "h： ", h)
    print("h/2", round(h/2), "w/2", round(w/2))
    #按像素点拆图
    subimg_p1 = mg_medianBlur[0:round(h/2) + 500, 0:w]
    subimg_p2 = mg_medianBlur[round(h/2) + 500:h, 0:w]
    # io.imshow(subimg_p1)
    # plt.show()
    # cv.imwrite('./pic/subimg_p1.png', subimg_p1); cv.imwrite('./pic/subimg_p2.png', subimg_p1)
    gray_bar(subimg_p1)
    gray_bar(subimg_p2)

    return subimg_p1, subimg_p2

# 二值化
def thresh_hold(gray_img, binary_1, binary_2):
    h, w = gray_img.shape
    for i in range(0, h - 1):
        for j in range(0, w - 1):
            if (binary_1 < gray_img[i, j] < binary_2):
                gray_img[i, j] = 200
            else:
                gray_img[i, j] = 0
    return gray_img

# 灰度直方图
def gray_bar(gray_img):
    h, w = gray_img.shape
    # print(h, w)
    xh = np.zeros((1, h))
    yw = np.zeros((1, w))
    for i in range(0, h - 1):
        for j in range(0, w - 1):
            if (100 < gray_img[i, j] < 250):
                xh[0, i] += 1
                yw[0, j] += 1
    # '''
    # 画分布直方图图img
    x1 = np.arange(0, h, 1)
    x2 = np.arange(0, w, 1)
    plt.bar(x1, xh[0])
    plt.show()
    plt.bar(x2, yw[0])
    plt.show()
    # '''
    # 找出高亮区域
    comb_num, signal = find_area(yw[0], w)
    print('final cuts:', signal)
    cut_width(comb_num, signal, gray_img, h)

    # subimg_p1 = img[0:round(h / 2) + 500, 0:w]

    return gray_img

def cut_width(comb_num, signal, gray_img, h):
    for i in range(0, signal + 1):
        if(comb_num[1][i]-comb_num[0][i]>20):
            # 宽度剪切后
            pic = gray_img[0:h, int(comb_num[0][i]):int(comb_num[1][i])]
            io.imshow(pic)
            plt.show()
            # '''
            # 高度剪切
            h1, w1 = pic.shape
            print("h1:", h1, "w1:", w1)
            # 高度分布直方图
            xh = cut_height(pic, h1, w1)
            x1 = np.arange(0, h1, 1)
            plt.bar(x1, xh[0])
            plt.show()
            mark, idx = trans_cord(xh[0], h1)
            rect_num, idx = sort_coordinate(mark, idx)
            if (idx > 0 and (rect_num[1][idx-1] - rect_num[0][0])>5):
                result = pic[int(rect_num[0][0]):int(rect_num[1][idx-1]), 0:w1]
                io.imshow(result)
                plt.show()

            # height_num, idx = find_area(xh[0], h1)
            # for j in range(0, idx - 1):
                # if (height_num[1][j] - height_num[0][j] > 1):
                # result = pic[int(height_num[0][j]):int(height_num[1][j]), 0:w1]
            # result = pic[int(xh[1][0]):int(xh[1][idx]), 0:w1]
            # io.imshow(result)
            # plt.show()
            #  '''
    return
# 找高度高亮区
def cut_height(img, h, w):
    xh = np.zeros((1, h))
    # yw = np.zeros((1, w))
    for i in range(0, h - 1):
        for j in range(0, w - 1):
            if (100 < img[i, j] < 250):
                xh[0, i] += 1
                # yw[0, j] += 1

    # print("xh:", xh)
    return xh


# 找宽度高亮区
def find_area(yw, w):
    mark, cnt = trans_cord(yw, w)
    print("idx:", cnt)
    rect_num, idx = sort_coordinate(mark, cnt)

    comb_num = np.zeros((2, idx))
    signal = 0
    i = 0
    while (i < idx):
        if (rect_num[0][i + 1] - rect_num[1][i] < 250):
            for j in range(i + 1, idx):
                if (rect_num[0][j + 1] - rect_num[1][j] < 250):
                    if(j+1 == idx):
                        comb_num[0][signal] = rect_num[0][i]
                        comb_num[1][signal] = rect_num[1][j+1]
                    else:
                        continue
                else:
                    comb_num[0][signal] = rect_num[0][i]
                    comb_num[1][signal] = rect_num[1][j]
                    # print('image: ', signal)
                    signal += 1
                    break
            i = j + 1
        else:
            comb_num[0][signal] = rect_num[0][i]
            comb_num[1][signal] = rect_num[1][i]
            # print('image: ', signal)
            signal += 1
            i += 1
    print("comb_num[0]:", comb_num[0])
    print("comb_num[1]:", comb_num[1])
    return comb_num, signal

def trans_cord(yw, w):
    mark = np.zeros((2, w))
    signal = 1
    idx = 0
    for i in range(0, w - 1):
        if (yw[i] != 0):
            mark[0][idx] = i
            mark[1][idx] += 1
            if np.all(signal == 0):
                idx += 1
            signal = 1
        else:
            signal = 0
            # print(mark[0][idx])
            # print(mark[1][idx])
    print("mark[0]:", mark[0])
    print("mark[1]:", mark[1])
    return mark, idx

# 坐标排序
def sort_coordinate(mark, signal):
    rect_num = np.zeros((2, signal))
    idx = 0
    if(signal==0):
        return rect_num, idx
    else:
        for i in range(0, signal + 1):
            if(mark[1][i]>2):
                rect_num[0][idx] = mark[0][i] + 1 - mark[1][i]
                rect_num[1][idx] = mark[0][i]
                idx += 1
    print("rect_num[0]", rect_num[0])
    print("rect_num[1]", rect_num[1])

    return rect_num, idx

# 分布直方图
def pixelmark(img):
    start_time = time.time()
    h, w, z = img.shape
    xh = np.zeros((1, h))
    yw = np.zeros((1, w))
    for i in range(0, h - 1):
        for j in range(0, w - 1):
            if(100<img[i, j, 0]<255 and 100<img[i, j, 1]<255 and 100<img[i, j, 2]<255):
                xh[0, i] += 1
                yw[0, j] += 1
                img[i, j, 0] = 255
                img[i, j, 1] = 0
                img[i, j, 2] = 0
    cv.imwrite('./data/img_mk.png', img)
    end_time = time.time()
    print("pixelmark time: ", end_time - start_time)
    return xh, yw

def main():
    input_Path = './data/1.png'
    img_paths = get_img(input_Path)
    print(img_paths)
    img1, img2 = cut_img(input_Path)
    # img1, img2 = split_img(input_Path)
    # xh, yw = pixelmark(img2)
    #h, w, z = img2.shape
    # plt.bar(h, xh)
    # plt.show()
    return

if __name__ == '__main__':
    main()